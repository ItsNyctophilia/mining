#!/usr/local/bin/python

from random import randint
from grading.utils.tracking import Tracker
from grading.utils.stats import Stats
import grading.timeout as timeout

class Tile:
    WALL = '#'
    ZERG = 'Z'
    EMPTY = ' '
    ACID = '~'
    MINERAL = '*'
    LANDING = '_'

class Location:
    def __init__(self, x, y):
        self.x = x
        self.y = y

    def __repr__(self):
        return f"Location({self.x}, {self.y})"

    def __str__(self):
        return f"({self.x:3}, {self.y:3})"

    def get_north(self):
        """ Returns a new tuple of the coordinates to the north of itself"""
        return Location(self.x, self.y-1).as_tuple()

    def get_south(self):
        """ Returns a new tuple of the coordinates to the south of itself"""
        return Location(self.x, self.y+1).as_tuple()

    def get_east(self):
        """ Returns a new tuple of the coordinates to the east of itself"""
        return Location(self.x+1, self.y).as_tuple()

    def get_west(self):
        """ Returns a new tuple of the coordinates to the west of itself"""
        return Location(self.x-1, self.y).as_tuple()

    def as_tuple(self):
        return (self.x, self.y)

class Map:

    def __init__(self, filename):
        """ Instantiates a map with dimensions x, y and populates it with
            a landing zone, minerals, acid and such
        """

        # A list of DroneContext objects
        self.drone_contexts = []

        # A list of lists of 1 char strings
        self.data = []

        # A list of MineralContext objects
        self.mineral = []

        # A list of 2-tuples, each one the coordinate of the acid
        self.acid = []


        # Open file representing a map and parse it character by chracter
        # To append to appropriate list as to whether it is acid, mineral
        with open(filename) as fh:
            for row, line in enumerate(fh):
                each_line = [char for char in line.rstrip()]
                for column, char in enumerate(each_line):
                    if char == Tile.ACID:
                        self.acid.append((column, row))
                    elif char == Tile.LANDING:
                        self.landing_zone = (column, row)
                    elif char in '0123456789':
                        each_line[column] = Tile.MINERAL
                        mineral_context = MineralContext(Location(column, row),
                                                         int(char))
                        self.mineral.append(mineral_context)

                self.data.append(each_line)

        self.__x = column
        self.__y = row
        self.xcoords = self.__x - 2
        self.ycoords = self.__y - 2
        self.total_minerals = sum(mc.amount for mc in self.mineral)
        

    def _get_coordinates(self):
        coordinates = (0, 0)
        while self[coordinates] != Tile.EMPTY:
            # Choose a random location on map excluding walls
            coordinates = (randint(1, self.xcoords), randint(1, self.ycoords))
        return coordinates


    def summary(self):
        """ Ratio of total minerals to reachable locations i.e walls are not counted"""
        # It is recommended when creating maps lke an 'L' with a lot of space outside 
        # Of the wall boundaries - that theat area be filled with wall characters so
        # it does not distort the summary value
        wall_count = 0
        for row in self.data:
            wall_count += row.count(Tile.WALL)

        total_minerals = sum(mineral.amount for mineral in self.mineral)
        total_coordinates = self.__x * self.__y
        return total_minerals / (total_coordinates - wall_count)

    def __str__(self):
        return '\n'.join(''.join(row) for row in self.data)

    def __getitem__(self, key):
        column, row = key
        return self.data[row][column]

    def __setitem__(self, key, val):
        column, row = key
        self.data[row][column] = val

    def what_is_at(self, key):
        for drone_context in self.drone_contexts:
            if drone_context.location == key:
                return Tile.ZERG
        return self[key]

    def add_mineral(self, amt):
        # Adds amount worth of minerals (*) to a random location on mapcz
        coordinates = self._get_coordinates()

        self[coordinates] = Tile.MINERAL
        mineral_context = MineralContext(Location(*coordinates), amt)
        self.mineral.append(mineral_context)


    def remove_zerg(self, z_id):
        for drone_context in self.drone_contexts:
            if z_id == id(drone_context.drones) and \
               (drone_context.location.x, drone_context.location.y) == self.landing_zone:
                self[drone_context.location.x, drone_context.location.y] = Tile.LANDING
                self.drone_contexts.remove(drone_context)
                return drone_context.mineral, drone_context.health
        return (None, None)

    def add_zerg(self, z, health):
        coordinates = self.landing_zone
        if self[coordinates] != Tile.LANDING:
            return False

        location = Location(*coordinates)
        self.update_location_adjacent(location)

        drone_context = DroneContext(location, z, health)
        self[location.x, location.y] = Tile.ZERG
        self.drone_contexts.append(drone_context)

        return True

    def update_location_adjacent(self, location):
        location.north = self[location.get_north()]
        location.south = self[location.get_south()]
        location.east = self[location.get_east()]
        location.west = self[location.get_west()]
        return location

    def find_mineralcontext_at(self, pos):
        for mineral_context in self.mineral:
            if mineral_context.location.x == pos[0] and mineral_context.location.y == pos[1]:
                return mineral_context

        return None

    def find_zergcontext_at(self, location):
        pos = location.as_tuple()
        for drone_context in self.drone_contexts:
            if drone_context.location.x == pos[0] and drone_context.location.y == pos[1]:
                return drone_context
        return None

    def move_to(self, location, destination):
        # Determine new location
        DESTINATIONS = {'NORTH':location.get_north, 'SOUTH':location.get_south,
                        'EAST':location.get_east, 'WEST':location.get_west}
        new_location = DESTINATIONS.get(destination, location.as_tuple)()

        # Get the tile at the new location
        tile = self[new_location]


        if new_location == location.as_tuple() or tile == Tile.ZERG:
            pass
        elif tile in [Tile.EMPTY, Tile.LANDING, Tile.ACID]:
            self[location.as_tuple()] = Tile.EMPTY
            self.update_tile(location)
            location.x, location.y = new_location
            self[new_location] = Tile.ZERG
            self.update_location_adjacent(location)
            Stats.stats.steps_calculated += 1
        elif tile == Tile.WALL:
            # Decrement health by one for hitting wall
            drone_context = self.find_zergcontext_at(location)
            drone_context.health -= 1
            # If standing on acid, also decrement
            if location == Tile.ACID:
                drone_context.health -=3
                Stats.stats.acid_steps += 1
            Stats.stats.wall_collisions += 1

        elif tile == Tile.MINERAL:
            # If standing on acid, also decrement
            if location == Tile.ACID:
                drone_context.health -=3
                Stats.stats.acid_steps += 1
            # Decrement number of minerals at that location
            # Increment the DroneContext's mineral count by one
            mineral_context = self.find_mineralcontext_at(new_location)
            if mineral_context.amount > 0:
                mineral_context.amount -= 1
                drone_context = self.find_zergcontext_at(location)
                drone_context.mineral += 1

                # If last mineral at location, reset tile to EMPTY
                if mineral_context.amount <= 0:
                    self[mineral_context.location.as_tuple()] = Tile.EMPTY
                    self.update_tile(mineral_context.location)
                    self.mineral.remove(mineral_context)

        else:
            raise Exception('UNKNOWN TERRAIN')

    def update_tile(self, location):
        coordinates = location.as_tuple()
        if coordinates == self.landing_zone:
            self[coordinates] = Tile.LANDING
        elif coordinates in self.acid:
            self[coordinates] = Tile.ACID

    def tick(self, controller):
        TOTAL_TIMEOUT = 1  # milliseconds
        for drone_context in self.drone_contexts:
            destination = 'CENTER'
            try:
                # Note: Any timeout occuring on multimove drone will prevent
                #       additional actions beingn called for that tick()
                for _ in range(drone_context.drones.moves):
                    self.update_location_adjacent(drone_context.location)
                    pos = drone_context.location.as_tuple()

                    for m in self.mineral:
                        if m.amount <= 0:
                            self[m.location.as_tuple] = Tile.EMPTY
                            self.update_tile(m.location)
                            self.mineral.remove(m)

                    if drone_context.location.as_tuple() in self.acid:
                        Tracker.acid_steps += 1 # Willing to step on acid
                        Stats.stats.acid_steps += 1
                        drone_context.health -= 3  # Acid is -3
                    if drone_context.health <= 0:
                        self[drone_context.location.as_tuple()] = Tile.EMPTY
                        self.update_tile(drone_context.location)
                        if drone_context in self.drone_contexts:
                            self.drone_contexts.remove(drone_context)

                    with timeout.within(TOTAL_TIMEOUT/drone_context.drones.moves):
                        destination = drone_context.drones.action(drone_context.location)

                    # Reset location position so that the zerg
                    # cannot track or abuse it
                    drone_context.location = Location(pos[0], pos[1])
                    self.update_location_adjacent(drone_context.location)

                    if drone_context in self.drone_contexts:
                        self.move_to(drone_context.location, destination)

                    if drone_context.drones.health <= 0:
                        Stats.stats.dead_drones += 1
                        controller.dead_drones += 1
                        if drone_context.mineral > 0:
                            Stats.stats.died_with_minerals += 1
                            Stats.stats.dead_minerals_lost += drone_context.mineral
                        break  # zerg is dead move on to next

            except timeout.TimeoutError2:
                Tracker.drone_timeouts += 1
                Stats.stats.drone_timeouts += 1
                Tracker.print(45 * "*", "Drone Timeout Occurred. Drone ID:", id(drone_context.drones))


class MineralContext:
    def __init__(self, location, amt):
        self.location = location
        self.amount = amt

    def __repr__(self):
        return f"MineralContext({repr(self.location)}, {self.amount})"

class DroneContext:
    def __init__(self, location, drones, health):
        self.location = location
        self.drones = drones
        self.health = health
        self.mineral = 0
