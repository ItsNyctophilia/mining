"""
This module is the entry point for starting the zerg mining project.
It attempt to import student package and classes and if successful
launches a GUI application to begin the running the program and gathering
stats as to the student accomplishments of spcefic tasks
"""

import sys
sys.dont_write_bytecode = True  # prevent creation of __pycache__ folders

# The check_imports module attempts to import required student modules/classes
# It raises a SystemExit exception if there any problems and this module will
# then exit as there is nothing that it can do to proceed further
from grading.utils import check_imports

# Reaching here implies the OVerlord and Dashboard classes exist
# allowing the program to successfully launch
from grading.utils.tracking import Tracker
from grading.utils.stats import Stats
from grading.zerg_expedition.gui.mining_expedition import MainController



try:
    Stats()  # initialize singleton available as class attribute
    MainController().mainloop()
except BaseException as base_exception:
    print("Problem: ", base_exception, type(base_exception))
finally:
    Stats.persist()
    Tracker.print_to.close()


