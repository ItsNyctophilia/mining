from collections import Counter
import pickle
import sys
import os


class Stats:
    stats = None
    FILE = "report/stats.pickle"

    def __new__(cls):
        if cls.stats is None:
            cls.stats = super(Stats, cls).__new__(cls)
            cls.stats.ticks = 0
            cls.stats.overlord_timeouts = 0
            cls.stats.over_capacity = 0
            cls.stats.drone_timeouts = 0
            cls.stats.acid_steps = 0
            cls.stats.deployed_to_summary_zero = 0
            cls.stats.minerals_collected = 0
            cls.stats.minerals_available = 0
            cls.stats.steps_calculated = 0
            cls.stats.steps_reported = 0
            cls.stats.steps_zero = 0
            cls.stats.refined_minerals = 0
            cls.stats.refined_minerals_unused = 0
            cls.stats.wall_collisions = 0
            cls.stats.died_with_minerals = 0
            cls.stats.dead_minerals_lost = 0
            cls.stats.first_deploy_not_highest_summary = 0
            cls.stats.used_fractional_refined = False
            cls.stats.refined_counts_match = True
            cls.stats.multi_move_drone_used = False
            cls.stats.steps_implemented = True
            cls.stats.dead_drones = 0
            cls.stats.drones_created = 0
            cls.stats.no_get_init_cost = set() # Types of drones without method
            cls.stats.deployed_types = set()
            cls.stats.all_drones_dead = []
            cls.stats.mined_everything = []
            cls.stats.unrecoverable_exceptions = 0
            if os.path.exists(cls.FILE):
                with open(cls.FILE, "rb") as stats_file:
                    cls.stats = pickle.load(stats_file)
        return cls.stats

    @classmethod
    def persist(cls):
        os.makedirs("report", exist_ok=True)
        with open(cls.FILE, "wb") as stats_file:
            pickle.dump(cls.stats, stats_file)
