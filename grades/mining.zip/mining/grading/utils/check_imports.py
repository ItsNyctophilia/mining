"""
This module attempts to import the mandatory student classes from the mandatory
package structure and raises an exception tpo the the program importing this
module if the requirements are not met as there is no use in attempting to run
the rest of the program against their code as it is obviously incorrect at this
point
"""


try:
    from mining import Overlord, Dashboard
except ImportError as ie:
    errmsg = "Problem importing mining.Overlord and/or mining.Dashboard"
    raise SystemExit(errmsg) from ie
except Exception as e:
    errmsg = "Problem while importing mining.Overlord and/or mining.Dashboard"
    raise SystemExit(errmsg) from e
