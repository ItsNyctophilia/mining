import sys
sys.dont_write_bytecode = True  # prevent creation of __pycache__ folders

from grading.utils.stats import Stats

def main():
    stats = Stats()
    data = [value for value in dir(stats) if (not value.startswith("__")) and value not in ["FILE", "stats","persist"]]
    with open("report/final_stats.txt", "w") as file:
        for value in data:
            print(value, getattr(stats, value), sep="\n\t", file=file)

if __name__ == "__main__":
        main()
