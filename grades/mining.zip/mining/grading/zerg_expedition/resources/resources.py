"""
This module is here simply to act as a path to this modules absolute path
on the file system that can be obtained using
# return os.path.abspath(os.path.dirname(resources.__file__))
"""
