#!/usr/bin/env python3
"""
Module contains the custom GUI components and main entry point for application
"""

# Standard Library imports
import os
import time
import datetime
import sys
import traceback
import tkinter as tk

# Project specific imports
import grading.timeout as timeout
import grading.zerg_map as zerg_map
from grading.utils.tracking import Tracker
from grading.utils.stats import Stats
from grading.utils.get_resources import resource_path

# Student requirement imports
from mining import Overlord, Dashboard



class MainController(tk.Tk):
    """ Acts as the root window for the GUI applciation and contains button
        and entry widgets to configure and start the zerg_mining project
    """
    
    dead_drones = 0
    mined_everything = False

    def __init__(self):
        """ Root window that contains fields for intial values """
        # Some UIs utilize the className argument as the title of
        # iconified window or pop up help so setting it here in addition
        # to calling self.title
        super().__init__(className="Zerg Mining Expedition")
        self.title("Zerg Mining Expedition")

        self.geometry("300x150+20-50")

        # Make sure the root window remains the top most window
        self.attributes("-topmost", True)

        # Include icon in titlebar, placement of icon varies by OS
        filename = os.path.join(resource_path(), "images", "logo_icon.png")
        self.iconphoto(False, tk.PhotoImage(file=filename))

        self._create_labeled_entries()

        # Place a label with blacnk text that can be used to show an error
        # message at some later point if needed.
        self.message = tk.Label(self, text=" ")
        self.message.pack()

        self.string_var = tk.StringVar(value="Tick Counter:")
        tk.Entry(self, textvariable=self.string_var,  width=30).pack()

        self.start_button = tk.Button(self, text="Start")
        self.start_button['command'] = self._get_the_ball_rolling
        self.start_button.pack()

        self.dashboard = Dashboard(self)

    def _create_labeled_entries(self):
        self.ticks = LabeledEntry(self, "Ticks:")
        self.refined = LabeledEntry(self, "Refined Minerals:")
        self.refresh = LabeledEntry(self, "Refresh Delay (sec):")
        self._reset_entries(errors = False)

    def _initialize_values(self):
        self.tick_count = int(self.ticks.entry.get())
        self.refined_count = int(self.refined.entry.get())
        self.refresh_delay = float(self.refresh.entry.get())

    def _reset_entry(self, widget, default_value, errors):
        widget.delete(0, tk.END)
        widget.insert(tk.END, default_value)
        if errors: widget["fg"] = "Red"

    def _reset_entries(self, errors=True):
        self._reset_entry(self.ticks.entry, str(Tracker.TICKS), errors)
        self._reset_entry(self.refined.entry, str(Tracker.REFINED_MINERALS), errors)
        self._reset_entry(self.refresh.entry, 0, errors)

    def _initialize_user_values(self):
        try:
            self._initialize_values()
        except Exception:
            self.message["text"] = "Invalid Value(s) : Reset to Defaults"
            self.message["fg"] = "Red"

            self._reset_entries()
            self._initialize_values()



    def _get_the_ball_rolling(self):
        """ Method is registered with start button """

        self.dashboard.geometry(f"+500-20")
        
        # Remove the button as it has been clicked
        # so that it can not be clicked again
        self.start_button.destroy()

        # set ticks, refined_minersals and refresh delay to value from GUI
        self._initialize_user_values()

        # Create Overlord and start up Tracker and the Stats
        self._initialize_all_components()
        self._track_configuration()
        self._track_drone_creation()
        self._arrange_top_levels()


        try:
            self._start_mining()
        except Exception as e:
            Stats.stats.unrecoverable_exceptions += 1
            print("Unrecoverable", type(e).__name__, "exception during mining",
                  file=sys.stderr)
            print(e, file=sys.stderr)
            exc_type, exc_value, exc_traceback = sys.exc_info()
            traceback.print_tb(exc_traceback, limit=10, file=sys.stderr)

            # Persist Stats, Close Tracker and Take screenshot as run is over
            Stats.persist()
            Tracker.print_to.close()
            os.system("gnome-screenshot --file=./report/" + Tracker.screenshot_file)
            raise SystemExit("Unable to continue the mining process") from e

    def _arrange_top_levels(self):
        all_toplevels = []
        # All Toplevel objects should now physically exist
        # Append all that are found associated to the dashboard to a list
        for k, v in self.dashboard.children.items():
            if isinstance(v, tk.Toplevel):
                all_toplevels.append(v)
        
        # If none were found, see if they were registered as children of root
        # Excluding the Dashboard Toplevel itself
        if not len(all_toplevels):
            for k, v in self.children.items():
                if isinstance(v, tk.Toplevel) and v is not self.dashboard:
                    all_toplevels.append(v)

        # If any were found, attempt to stagger them on display such that they
        # are not all on top of each other.
        if len(all_toplevels):
            width = all_toplevels[0].winfo_width() + 100
            if width < 300:
                    width = 1200
            for counter, toplevel in enumerate(all_toplevels):
                toplevel.geometry(f"+{counter * width}+0")

    def _load_maps(self):
        file_maps = Tracker.FILE_MAPS  # Dictionary of lists of file names
        file_key = Tracker.FILE_KEY    # Which list within Dictionary to use
        file_list = file_maps[file_key]

        for idx, file_map in enumerate(file_list):
            self.maps[idx] = zerg_map.Map(file_map) 


    def _initialize_all_components(self):
        self.maps = {}
        self._load_maps()

        # Create Overlord, at which time all Drones are to be created by
        # constructor of the Overlord
        self.overlord = Overlord(self.tick_count, self.refined_count,
                                 self.dashboard)
        
        # Register all available maps with Overlord by id and summary
        for idx, map_ in self.maps.items():
            self.overlord.add_map(idx, map_.summary())

        # All drone creation is required to have been completed by 
        # Overlords constructor, so obtain a tuple of all drone instances
        self.original_drones = tuple(self.overlord.drones.values())

        # Obtain the total number of available minerals from all maps
        mineral_counts = [m.total_minerals for m in self.maps.values()]
        self.total_minerals_available = sum(mineral_counts)

        # Represents dictionary of drone id as key and zerg_map id as value
        self.drone_locations = {id_: None for id_ in self.overlord.drones}

        # Create dictionary of drone healths mapped to drone id
        self.drone_healths = {}
        for id_, drone_ in self.overlord.drones.items():
            self.drone_healths[id_] = drone_.health
    
        # Total number of minerals successfuly mined by drones
        self.mined = 0

    def _track_configuration(self):
        # Initialize Stats with the ticks and refined_minerals and 
        # total minerals available from all 3 maps for this run of the program
        Stats.stats.ticks += self.tick_count
        Stats.stats.refined_minerals += self.refined_count
        Stats.stats.minerals_available += self.total_minerals_available

        # Pass a copy of the dictionary of original drones to the Tracker
        Tracker.original_drones = dict(self.overlord.drones)
        
        # Track the map files used and the summary of each.
        Tracker.map_summaries = {key:map_.summary() for key, map_ in self.maps.items()}
        fmt_string = "{:}  {}"
        Tracker.trackln(fmt_string.format("Map:", "Summary:"))
        for map_, summary_ in zip(Tracker.FILE_MAPS[Tracker.FILE_KEY],
                                  Tracker.map_summaries.values()):
            Tracker.trackln(fmt_string.format(map_, summary_))
        Tracker.newline(2)
        
        # Track the ticks, refined minerals and minerals available
        Tracker.trackln("Ticks: ", Tracker.TICKS)
        Tracker.trackln("Refined Minerals: ", Tracker.REFINED_MINERALS)
        mineral_count = sum(map_.total_minerals for map_ in self.maps.values())
        Tracker.trackln("Minerals Available: ", mineral_count)
        Tracker.newline(2)

        
        
    def _track_drone_creation(self):
        # Determine length of longest Drone class name to use for formatting
        max_ = len(max({type(a_drone).__name__  for  a_drone in self.overlord.drones.values()}, key=len)) + 7
        
        Tracker.trackln("Initial Drone Data:")
        Tracker.trackln("# of Drones Created: ", len(self.overlord.drones))
        
        # Track each drone's id and type
        fmt_string = "{1:<18}{2:{0}}{3:^7}{4:^7}{5:^10}{6:^8}"
        headers = ["ID", "Type", "Moves", "Cost", "Capacity", "Health"]

        Tracker.trackln(fmt_string.format(max_, *headers))

        total_init_cost = 0
        init_cost_errors = set()
        for drone_id in self.overlord.drones:
            init_cost_error = ""
            try:
                the_drone = self.overlord.drones[drone_id]
                init_cost = type(the_drone).get_init_cost()
            except Exception as e:
                Stats.stats.no_get_init_cost.add(type(the_drone))
                init_cost_errors.add(type(the_drone))
                init_cost = "Invalid"

            the_drone = self.overlord.drones[drone_id]
            Stats.stats.deployed_types.add(type(the_drone).__name__)

            # calculate the actual cost of the instantiated Drone
            actual_init_cost = the_drone.capacity / 5 + the_drone.health / 10 + the_drone.moves * 3


            Tracker.trackln(fmt_string.format(max_, id(the_drone),
                           type(the_drone).__name__, the_drone.moves, init_cost,
                           the_drone.capacity, the_drone.health))
            
            if the_drone.capacity % 5 != 0 or the_drone.health % 10 != 0:
                Stats.stats.used_fractional_refined = True
                init_cost_error = "\u26d4"
            if actual_init_cost != init_cost:
                Stats.stats.refined_counts_match = False
                init_cost_error = "\u26d4"
            
            if init_cost_error:
                Tracker.trackln("\t\u26d4 Above drone's actual cost does not match its stated cost.")
                Tracker.trackln("\t\tStated Cost: ", init_cost, "   Actual Cost: ", actual_init_cost)



            total_init_cost += actual_init_cost
            if the_drone.moves > 1:
                Stats.stats.multi_move_drone_used = True
        Tracker.newline(2)

        if init_cost_errors:
            Tracker.trackln("The following Drone types do NOT implement 'get_init_cost()' properly")
            Tracker.trackln(", ".join([datatype.__name__  for datatype in init_cost_errors]))
        Tracker.newline(2)

        Stats.stats.refined_minerals_unused += (self.refined_count - total_init_cost)

        



    def _start_mining(self):
        start = time.time()
        try:
            first_deployment = True

            # For each tick call the Overlord's action and then process
            # its return value
            for a_tick in range(self.tick_count):
                txt = f"Tick Counter: {a_tick}"
                self.overlord.dashboard.master.string_var.set(txt)
                self.overlord.dashboard.master.update() #trigger GUI update
                self._invoke_overlord_action(first_deployment, a_tick)

                
                Tracker.print("Tick:", a_tick, " Mined:", self.mined, "\tPost Overlord action", " : ", "Pre Drone action(s)")
                fmt = "\t{:^7}{:<20}{:^15}{:^15}{:^13}"
                Tracker.print(fmt.format("Map#", "DroneID", "Actual(x, y)", "ActualHealth:", "YourHealth:"))
                for n in self.maps:
                    for drone_ctx in self.maps[n].drone_contexts:
                        Tracker.print(fmt.format(n, id(drone_ctx.drones),
                                        str(drone_ctx.location), drone_ctx.health,
                                        drone_ctx.drones.health))
                Tracker.print()

                # Deterimine if all drones are dead
                if len(self.original_drones) == MainController.dead_drones:
                    Stats.stats.all_drones_dead.append(f"Tick {a_tick} of {self.tick_count}")
                    Tracker.trackln(2)
                    Tracker.print("All Drones have died")
                    break   #All drones are dead - no need to continue


                for n in self.maps:
                    self.maps[n].tick(MainController)
                    Tracker.print(self.maps[n])

                # Sleep for refresh_delay seconds to slow down visuals if needed
                time.sleep(self.refresh_delay)

        except KeyboardInterrupt:
            print("All Actions stopped with Ctrl-C", file=sys.stderr)
            Tracker.print("Program stopped with Ctrl-C", file=sys.stderr)

        Stats.stats.drones_created += len(self.original_drones)

        for each_drone in self.original_drones:
            if not hasattr(each_drone, "steps"):
                Stats.stats.steps_implemented = False
            else:
                steps = each_drone.steps()
                if not steps:
                    Stats.stats.steps_zero += 1
                else:
                    Stats.stats.steps_reported += steps



        Tracker.trackln("Number of times drone deployed to zerg_map with summary zero: ", Tracker.deployed_to_summary_zero)
        Tracker.trackln("Overlord Timeouts: ", Tracker.overlord_timeouts)
        Tracker.trackln("Drone Timeouts: ", Tracker.drone_timeouts)
        Tracker.trackln("Capacity Overload Total Lost: ", Tracker.over_capacity)
        Tracker.trackln("Total Mined: " , self.mined)
        Tracker.trackln("Willing to step on acid: ", Tracker.acid_steps,  " times")

        total_steps = 0
        try:
            for drone_id in Tracker.original_drones:
                total_steps += Tracker.original_drones[drone_id].steps()
            Tracker.trackln("Total Reported Steps: ", total_steps)
        except Exception as e:
            Tracker.trackln("\u26d4 steps() Not implemented")

        Tracker.trackln("Final Reported Drone Data:")
        fmt = "{:<20}{:^8}   {}"
        Tracker.trackln(fmt.format("DroneID", "Health", "Steps"))
        for drone_id in Tracker.original_drones:
            the_drone = Tracker.original_drones[drone_id]
            try:
                step_data = the_drone.steps()
            except Exception as e:
                step_data = "\u26d4 steps() Not implemented"
            Tracker.trackln(fmt.format(id(the_drone), the_drone.health,
                                       step_data))

        
        elapsed_time = str(datetime.timedelta(seconds=(time.time() - start)))
        Tracker.trackln("Elapsed Time hh:mm:ss: ", elapsed_time)
        Tracker.print("Elapsed Time hh:mm:ss: ", elapsed_time)
        
        result = "".join(Tracker.collected_data)
        print(result, file=sys.stderr)

        with open("report/" + Tracker.summary_file, "w") as summary:
            print(result, end="\n"*3, file=summary)
            os.system("gnome-screenshot --file=./report/" + Tracker.screenshot_file)


        self.overlord.dashboard.master.focus_set()
        #self.destroy()
        #exit("Program Completed Normally")

    def _invoke_overlord_action(self, first_deployment, a_tick):
        action = 'NONE'
        try:
            with timeout.within(1000):
                action = self.overlord.action(None)

        except timeout.TimeoutError2:
            Stats.stats.overlord_timeouts += 1
            Tracker.overlord_timeouts += 1
            timeout_msg = f"\u231B Overlord Timeout: Tick# {a_tick}:04"
            Tracker.print(timeout_msg)
        else:
            if action.startswith('DEPLOY'):
                self._handle_deploy(first_deployment, action)
                first_deployment = False

            elif action.startswith('RETURN'):
                self._handle_return(action)

            if not MainController.mined_everything and self.total_minerals_available == self.mined:
                Stats.stats.mined_everything.append(f"Tick {a_tick} of {self.tick_count}")
                MainController.mined_everything = True


    def _handle_deploy(self, first_deployment, action):
        drone_id, map_id = action[6:].split()
        drone_id = int(drone_id)
        map_id = int(map_id)

        # Determine if first deployment is to highest map.summary()
        if first_deployment:
            largest_summary = max([map.summary() for map in self.maps.values()])
            current_summary = self.maps[map_id].summary()
            if current_summary < largest_summary:
                Stats.stats.stats.first_deploy_not_highest_summary += 1

        if Tracker.map_summaries[map_id] == 0:
            Tracker.deployed_to_summary_zero += 1
            Stats.stats.deployed_to_summary_zero += 1
        if self.drone_locations[drone_id] is None:
            if self.maps[map_id].add_zerg(self.overlord.drones[drone_id],
                                    self.drone_healths[drone_id]):
                self.drone_locations[drone_id] = map_id

    
    def _handle_return(self, action):
        drone_id = int(action[6:])

        if self.drone_locations[drone_id] is not None:
            map_id = self.drone_locations[drone_id]
            extracted, health = self.maps[map_id].remove_zerg(drone_id)
            if extracted is not None:
                #check to see if they exceeded capacity
                capacity = Tracker.original_drones[drone_id].capacity
                if extracted > capacity:
                    Stats.stats.over_capacity += extracted - capacity
                    Tracker.over_capacity += extracted - capacity
                    extracted = capacity

                self.drone_locations[drone_id] = None  # Not on zerg_map anymore
                self.drone_healths[drone_id] = health
                self.mined += extracted
                Stats.stats.minerals_collected += extracted

class LabeledEntry(tk.Frame):
    def __init__(self, owner, label, default=""):
        super().__init__(owner)
        self.label = tk.Label(self, text=label, width=20)
        self.label.pack(side=tk.LEFT)
        self.entry = tk.Entry(self, width=5)
        self.entry.insert(tk.END, default)
        self.entry.pack(side=tk.LEFT)
        self.pack()

if __name__ == "__main__":
    main()
