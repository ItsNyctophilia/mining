import os
from grading.zerg_expedition.resources import resources
def resource_path():
    return os.path.abspath(os.path.dirname(resources.__file__))

