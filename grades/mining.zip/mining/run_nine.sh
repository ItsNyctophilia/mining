python3 grade_mining_expedition.py 100   9 0
reset
python3 grade_mining_expedition.py 100 200 0
reset
python3 grade_mining_expedition.py 200 200 0
reset
python3 grade_mining_expedition.py 100 200 1
reset
python3 grade_mining_expedition.py 500 200 1
reset
python3 grade_mining_expedition.py 100 200 2
reset
python3 grade_mining_expedition.py 500 200 2
reset
python3 grade_mining_expedition.py 5000 5000 1
reset
python3 grade_mining_expedition.py 10000 9 1
reset
python3 -m grading.final_stats
